Compound Graph Viewer for ArchiMate
================================================================================

## Description

This application is a prototype aiming at providing a proof of value for modeling with ArchiMate on top of  a solution combining advanced interactive visualization and graph theory based analysis and processing capabilities.

The goal is to be able to export ArchiMate models produced 

by Modeling platforms: Enterprise Architect, Archi, Cameo ... 
and Enteprise Repositories content: organization repository, BMS, Compass, etc.

as aggregation of semantic graphs based on ArchiMate language semantic 

